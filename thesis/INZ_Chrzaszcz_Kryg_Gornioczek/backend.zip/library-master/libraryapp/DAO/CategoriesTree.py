9
class CategoriesTree():

    def __init__(self, main_category, subcategories):
        self.main_category = main_category
        self.subcategories = subcategories