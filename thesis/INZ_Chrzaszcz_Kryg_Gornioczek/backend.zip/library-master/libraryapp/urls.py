from django.urls import path
from . import views

urlpatterns = [
    # path('', views.library_site, name='library_site'),
]