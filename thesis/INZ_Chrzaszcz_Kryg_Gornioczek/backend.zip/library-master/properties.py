PROJECT_PATH="/home/<path_to>/libproject/"
VENV="libvenv"
HOST="127.0.0.1:8000"
LOG_FILE="logs"

SECRET_KEY=')eu7q%maa(4h5x&74rcqx-^j-g-r4yax%#1(jj=)7wp=pvgn!d'
ALLOWED_HOSTS=['127.0.0.1','localhost',]

USER_NAME="admin"
PASSWORD="super_password"
MAIL="admin@mail.com"
